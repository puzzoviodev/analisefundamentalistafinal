# Variações de Tema – Ex2 Cards Grid (HTML + CSS)

Este pacote contém **6 variações de tema CSS** para aplicar sobre o seu layout base.

## Como usar (passo a passo)
1. **Garanta** que o seu HTML referencia o CSS **base** fornecido por você:
   ```html
   <link rel="stylesheet" href="ex2_cards_grid.css">
   ```
2. **Adicione** logo abaixo **UM** dos arquivos de variação (somente um por vez):
   ```html
   <link rel="stylesheet" href="variants/variant-01_minimal-light.css">
   <!-- ou -->
   <link rel="stylesheet" href="variants/variant-02_neo-dark.css">
   <!-- ... -->
   ```
3. **Pronto.** O **HTML não precisa ser alterado** (as classes `.grid`, `.card`, `.chip`, etc. continuam válidas). Se quiser testar outro tema, troque apenas o `href` do segundo `<link>`.

> Dica: Se preferir, você pode montar um seletor de temas no servidor (ex.: querystring `?theme=...`) e renderizar o `<link>` correspondente dinamicamente.

## Lista de temas
1. **Minimal Light** – claro, leve, AA.
2. **Neo Dark** – dark refinado, ciano/azul.
3. **Corporate Blue** – claro corporativo, azuis sóbrios (Inter opcional).
4. **Magazine Serif** – editorial, títulos em serif (Merriweather opcional).
5. **Glassmorphism** – cartões translúcidos com blur (fallback).
6. **High-Contrast A11y** – contraste alto, foco evidente, fontes maiores.

## Observações
- Os temas sobrescrevem **variáveis CSS** (`:root`) e pequenos detalhes (sombra, foco). Carregue-os **depois** do CSS base.
- As variações que usam `@import` do Google Fonts são **opcionais**. Caso sua política bloqueie fontes externas, remova a linha `@import` – haverá fallback para system fonts.
- `backdrop-filter` (Glassmorphism) tem suporte moderno; em navegadores legados o visual cai no **fallback opaco**, preservando a legibilidade.
- Impressão: se precisar de um tema específico para imprimir, diga e eu gero uma variação **print-friendly** (sem cor de fundo e sem sombras).

---
Feito com 💙 para o Silvio.
